package test_interfaces;

public interface A2 {
 //data members : public static final 
	int DATA2=2345;
	//method : public abstract
	boolean isEven(int no);
}
