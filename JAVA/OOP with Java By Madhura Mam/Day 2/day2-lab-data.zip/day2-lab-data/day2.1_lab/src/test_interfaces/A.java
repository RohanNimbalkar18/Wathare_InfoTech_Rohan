package test_interfaces;

public interface A {
 //data members : public static final 
	int DATA=12345;
	//method : public abstract
	void print(String mesg);
}
