package com.iacsd.core;

import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * chasisNo(string) : Unique ID, color(enum) , basePrice(double) ,
 *  manufactureDate(Date),company,isAvailable
 */
public class Vehicle {
	private String chasisNo;
	private Color vehicleColor;
	private double price;
	private Date manufactureDate;
	private String company;
	private boolean isAvailable;
	//add simple date formatter
	public static SimpleDateFormat sdf;
	
	static {
		sdf=new SimpleDateFormat("dd-MM-yyyy");
	}

	public Vehicle(String chasisNo, Color vehicleColor, double price, Date manufactureDate, String company) {
		super();
		this.chasisNo = chasisNo;
		this.vehicleColor = vehicleColor;
		this.price = price;
		this.manufactureDate = manufactureDate;
		this.company = company;
		this.isAvailable = true;
	}

	
	//How to add a formatted date string instead of Date's toString?
	@Override
	public String toString() {
		return "Vehicle [chasisNo=" + chasisNo + ", vehicleColor=" + vehicleColor + ", price=" + price
				+ ", manufactureDate=" + sdf.format(manufactureDate) + ", company=" + company + ", isAvailable=" + isAvailable
				+ "]";
	}

	@Override
	public boolean equals(Object o) {
		System.out.println("in vehicle's eq");
		if (o instanceof Vehicle) {
			Vehicle v=(Vehicle)o;
			return this.chasisNo.equals(v.chasisNo);
		}
		return false;
	}

}
