package test_interfaces;

public interface A3 extends A, A2 {
	double calc(double d1, double d2);
}
