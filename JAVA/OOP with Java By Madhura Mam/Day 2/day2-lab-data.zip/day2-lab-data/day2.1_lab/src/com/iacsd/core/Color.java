package com.iacsd.core;

public enum Color {
	WHITE, BLACK, BLUE, SILVER, RED
}
