package test_interfaces;

public class B implements A3{

	@Override
	public void print(String mesg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isEven(int no) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double calc(double d1, double d2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
