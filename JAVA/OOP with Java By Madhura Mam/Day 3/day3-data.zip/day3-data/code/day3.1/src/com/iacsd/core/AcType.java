package com.iacsd.core;

public enum AcType {
	SAVING, CURRENT, FD, DMAT, LOAN, NRE
}
